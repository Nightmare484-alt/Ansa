package com.maya.assistant

import com.maya.assistant.ai.AnthropicClient
import com.maya.assistant.ai.ChatError
import com.maya.assistant.ai.ChatException
import com.maya.assistant.ai.ChatRequest
import com.maya.assistant.data.ChatMessage
import com.maya.assistant.data.Role
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class AnthropicClientTest {
    private fun req(image: ByteArray? = null, web: Boolean = false) = ChatRequest(
        system = "sys", history = listOf(ChatMessage(Role.USER, "hi"), ChatMessage(Role.ASSISTANT, "hello")),
        userText = "what is this", image = image, model = "m", apiKey = "k", webSearch = web,
    )

    @Test fun bodyHasHistoryAndNoToolsByDefault() {
        val o = JSONObject(AnthropicClient.buildBody(req()))
        assertEquals("m", o.getString("model"))
        assertEquals(3, o.getJSONArray("messages").length())
        assertFalse(o.has("tools"))
        assertFalse(o.toString().contains("\"k\"")) // the key goes in a header, never the body
    }

    @Test fun bodyIncludesImageAndWebSearch() {
        val o = JSONObject(AnthropicClient.buildBody(req(image = byteArrayOf(1, 2, 3), web = true)))
        val content = o.getJSONArray("messages").getJSONObject(2).getJSONArray("content")
        assertEquals("image", content.getJSONObject(0).getString("type"))
        assertEquals("image/jpeg", content.getJSONObject(0).getJSONObject("source").getString("media_type"))
        assertEquals("text", content.getJSONObject(1).getString("type"))
        assertEquals("web_search", o.getJSONArray("tools").getJSONObject(0).getString("name"))
    }

    @Test fun parsesAndJoinsTextBlocksIgnoringOthers() {
        val json = """{"content":[{"type":"text","text":"Hello "},{"type":"server_tool_use"},{"type":"text","text":"there"}]}"""
        assertEquals("Hello there", AnthropicClient.parseResponse(json))
    }

    @Test fun emptyOrMalformedResponsesAreBadResponse() {
        for (bad in listOf("""{"content":[]}""", "not json", """{"x":1}""")) {
            try {
                AnthropicClient.parseResponse(bad); fail("expected failure for $bad")
            } catch (e: ChatException) {
                assertEquals(ChatError.BAD_RESPONSE, e.error)
            }
        }
    }

    @Test fun statusCodesMap() {
        assertEquals(ChatError.UNAUTHORIZED, AnthropicClient.mapStatus(401))
        assertEquals(ChatError.RATE_LIMITED, AnthropicClient.mapStatus(429))
        assertEquals(ChatError.OVERLOADED, AnthropicClient.mapStatus(529))
        assertEquals(ChatError.SERVER, AnthropicClient.mapStatus(503))
        assertEquals(ChatError.BAD_REQUEST, AnthropicClient.mapStatus(400))
        assertTrue(AnthropicClient.mapStatus(302) == ChatError.UNKNOWN)
    }
}
