package com.maya.assistant

import com.maya.assistant.capture.ImageUtils
import com.maya.assistant.vm.MicAction
import com.maya.assistant.vm.decideMicAction
import com.maya.assistant.voice.SpeechError
import com.maya.assistant.voice.mapSpeechError
import com.maya.assistant.voice.stripMarkdown
import android.speech.SpeechRecognizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class PermissionAndTextTest {
    @Test fun micPermissionFlow() {
        assertEquals(MicAction.START, decideMicAction(granted = true, shouldShowRationale = false, askedBefore = true))
        assertEquals(MicAction.REQUEST, decideMicAction(false, false, askedBefore = false))
        assertEquals(MicAction.SHOW_RATIONALE, decideMicAction(false, true, true))
        assertEquals(MicAction.OPEN_SETTINGS, decideMicAction(false, false, askedBefore = true))
    }

    @Test fun speechErrorsMap() {
        assertEquals(SpeechError.NO_MATCH, mapSpeechError(SpeechRecognizer.ERROR_NO_MATCH))
        assertEquals(SpeechError.TIMEOUT, mapSpeechError(SpeechRecognizer.ERROR_SPEECH_TIMEOUT))
        assertEquals(SpeechError.NETWORK, mapSpeechError(SpeechRecognizer.ERROR_NETWORK))
        assertEquals(SpeechError.BUSY, mapSpeechError(SpeechRecognizer.ERROR_RECOGNIZER_BUSY))
        assertEquals(SpeechError.PERMISSION, mapSpeechError(SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS))
        assertEquals(SpeechError.OTHER, mapSpeechError(999))
    }

    @Test fun markdownIsStrippedForSpeech() {
        assertEquals("Hello world", stripMarkdown("**Hello** `world`"))
        assertEquals("See docs", stripMarkdown("See [docs](https://x.y)"))
        assertFalse(stripMarkdown("```kotlin\nval x = 1\n```").contains("val x"))
    }

    @Test fun imageSizing() {
        assertEquals(1, ImageUtils.sampleSize(1000, 800))
        assertEquals(2, ImageUtils.sampleSize(4000, 3000))
        assertEquals(1f, ImageUtils.scaleFor(800, 600), 0f)
        assertEquals(0.5f, ImageUtils.scaleFor(2560, 1440), 0.001f)
    }
}
