package com.maya.assistant.ai

import com.maya.assistant.data.ChatMessage

enum class ChatError {
    MISSING_KEY, UNAUTHORIZED, RATE_LIMITED, OVERLOADED, BAD_REQUEST, SERVER, NETWORK, TIMEOUT, BAD_RESPONSE, UNKNOWN
}

class ChatException(val error: ChatError, cause: Throwable? = null) : Exception(error.name, cause)

class ChatRequest(
    val system: String,
    val history: List<ChatMessage>,
    val userText: String,
    val image: ByteArray?,
    val model: String,
    val apiKey: String,
    val webSearch: Boolean,
)

interface ChatClient {
    /** Returns the assistant's reply text or throws [ChatException]. */
    suspend fun send(request: ChatRequest): String
}
