package com.maya.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

enum class SpeechError { NO_MATCH, TIMEOUT, NETWORK, BUSY, PERMISSION, UNAVAILABLE, OTHER }

fun mapSpeechError(code: Int): SpeechError = when (code) {
    SpeechRecognizer.ERROR_NO_MATCH -> SpeechError.NO_MATCH
    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> SpeechError.TIMEOUT
    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
    SpeechRecognizer.ERROR_SERVER -> SpeechError.NETWORK
    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> SpeechError.BUSY
    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> SpeechError.PERMISSION
    else -> SpeechError.OTHER
}

interface SpeechListener {
    fun onPartial(text: String)
    fun onResult(text: String)
    fun onError(error: SpeechError)
}

interface SpeechInput {
    val available: Boolean
    fun start(listener: SpeechListener)
    /** Stop listening and deliver what was heard so far. */
    fun stop()
    fun cancel()
    fun release()
}

/** Wraps the on-device/system [SpeechRecognizer]. Must be used from the main thread. */
class AndroidSpeechInput(private val context: Context) : SpeechInput {
    private var recognizer: SpeechRecognizer? = null

    override val available: Boolean get() = SpeechRecognizer.isRecognitionAvailable(context)

    override fun start(listener: SpeechListener) {
        if (!available) return listener.onError(SpeechError.UNAVAILABLE)
        cancel()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isBlank()) listener.onError(SpeechError.NO_MATCH) else listener.onResult(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    ?.let { if (it.isNotBlank()) listener.onPartial(it) }
            }
            override fun onError(error: Int) = listener.onError(mapSpeechError(error))
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        r.startListening(intent)
    }

    override fun stop() {
        recognizer?.stopListening()
    }

    override fun cancel() {
        recognizer?.let {
            it.cancel()
            it.destroy()
        }
        recognizer = null
    }

    override fun release() = cancel()
}
