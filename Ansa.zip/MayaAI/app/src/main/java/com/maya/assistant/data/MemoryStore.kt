package com.maya.assistant.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

interface MemoryStore {
    fun all(): List<MemoryNote>
    /** Returns the saved note, or null if the text was blank. */
    fun add(text: String): MemoryNote?
    fun remove(id: Long)
    fun clear()
}

/**
 * Notes the user explicitly asked Maya to remember ("remember that ..."), kept only on this
 * device in app-private storage. Bounded in count and length; oldest notes drop first.
 */
class FileMemoryStore(
    private val file: File,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val maxNotes: Int = 100,
    private val maxLength: Int = 300,
) : MemoryStore {

    private var cache: MutableList<MemoryNote>? = null

    @Synchronized
    override fun all(): List<MemoryNote> = load().toList()

    @Synchronized
    override fun add(text: String): MemoryNote? {
        val clean = text.trim().replace(Regex("\\s+"), " ").take(maxLength)
        if (clean.isEmpty()) return null
        val notes = load()
        notes.firstOrNull { it.text.equals(clean, ignoreCase = true) }?.let { return it }
        val id = maxOf(clock(), (notes.maxOfOrNull { it.id } ?: 0L) + 1)
        val note = MemoryNote(id, clean, clock())
        notes.add(note)
        while (notes.size > maxNotes) notes.removeAt(0)
        save(notes)
        return note
    }

    @Synchronized
    override fun remove(id: Long) {
        val notes = load()
        if (notes.removeAll { it.id == id }) save(notes)
    }

    @Synchronized
    override fun clear() {
        cache = mutableListOf()
        file.delete()
    }

    private fun load(): MutableList<MemoryNote> {
        cache?.let { return it }
        val list = mutableListOf<MemoryNote>()
        try {
            if (file.exists()) {
                val arr = JSONArray(file.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(MemoryNote(o.getLong("id"), o.getString("text"), o.optLong("at")))
                }
            }
        } catch (e: Exception) {
            list.clear() // corrupt file: start empty rather than crash
        }
        cache = list
        return list
    }

    private fun save(notes: List<MemoryNote>) {
        val arr = JSONArray()
        notes.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("at", it.createdAt)) }
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(file)) {
            file.writeText(arr.toString())
            tmp.delete()
        }
    }
}
