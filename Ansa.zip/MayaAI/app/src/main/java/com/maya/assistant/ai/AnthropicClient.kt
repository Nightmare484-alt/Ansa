package com.maya.assistant.ai

import com.maya.assistant.data.Role
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.Base64

/** Minimal Anthropic Messages API client (no third-party HTTP library). */
class AnthropicClient(
    private val endpoint: String = "https://api.anthropic.com/v1/messages",
) : ChatClient {

    override suspend fun send(request: ChatRequest): String = withContext(Dispatchers.IO) {
        if (request.apiKey.isBlank()) throw ChatException(ChatError.MISSING_KEY)
        val body = buildBody(request)
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = if (request.webSearch) 90_000 else 60_000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", request.apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code in 200..299) parseResponse(text) else throw ChatException(mapStatus(code))
        } catch (e: ChatException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw ChatException(ChatError.TIMEOUT, e)
        } catch (e: IOException) {
            throw ChatException(ChatError.NETWORK, e)
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        const val MAX_TOKENS = 1024

        fun buildBody(r: ChatRequest): String {
            val messages = JSONArray()
            r.history.forEach {
                messages.put(
                    JSONObject()
                        .put("role", if (it.role == Role.USER) "user" else "assistant")
                        .put("content", it.text)
                )
            }
            val content = JSONArray()
            if (r.image != null) {
                content.put(
                    JSONObject().put("type", "image").put(
                        "source",
                        JSONObject()
                            .put("type", "base64")
                            .put("media_type", "image/jpeg")
                            .put("data", Base64.getEncoder().encodeToString(r.image))
                    )
                )
            }
            content.put(JSONObject().put("type", "text").put("text", r.userText))
            messages.put(JSONObject().put("role", "user").put("content", content))

            val root = JSONObject()
                .put("model", r.model)
                .put("max_tokens", MAX_TOKENS)
                .put("system", r.system)
                .put("messages", messages)
            if (r.webSearch) {
                root.put(
                    "tools",
                    JSONArray().put(
                        JSONObject()
                            .put("type", "web_search_20250305")
                            .put("name", "web_search")
                            .put("max_uses", 3)
                    )
                )
            }
            return root.toString()
        }

        fun parseResponse(json: String): String {
            val content = try {
                JSONObject(json).getJSONArray("content")
            } catch (e: JSONException) {
                throw ChatException(ChatError.BAD_RESPONSE, e)
            }
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.optJSONObject(i) ?: continue
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
            val out = sb.toString().trim()
            if (out.isEmpty()) throw ChatException(ChatError.BAD_RESPONSE)
            return out
        }

        fun mapStatus(code: Int): ChatError = when (code) {
            400, 404, 413, 422 -> ChatError.BAD_REQUEST
            401, 403 -> ChatError.UNAUTHORIZED
            429 -> ChatError.RATE_LIMITED
            529 -> ChatError.OVERLOADED
            in 500..599 -> ChatError.SERVER
            else -> ChatError.UNKNOWN
        }
    }
}
