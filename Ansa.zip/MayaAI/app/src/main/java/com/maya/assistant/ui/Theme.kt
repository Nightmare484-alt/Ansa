package com.maya.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.maya.assistant.vm.UiError

val Navy = Color(0xFF050B24)
val MayaBlue = Color(0xFF2F6BFF)
val MayaCyan = Color(0xFF4DA3FF)
val MayaViolet = Color(0xFFA25CFF)
val CardBg = Color(0xE6101E55)

@Composable
fun MayaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = MayaBlue,
            onPrimary = Color.White,
            background = Navy,
            onBackground = Color.White,
            surface = Color(0xFF0B1537),
            onSurface = Color.White,
            surfaceVariant = Color(0xFF16245E),
            onSurfaceVariant = Color(0xFFC8D4FF),
        ),
        content = content,
    )
}

fun UiError.message(): String = when (this) {
    UiError.MISSING_KEY -> "I need an API key first. Open Settings and paste your key."
    UiError.UNAUTHORIZED -> "The API key was rejected. Check it in Settings."
    UiError.RATE_LIMITED -> "Too many requests right now. Please try again in a minute."
    UiError.OVERLOADED -> "The AI service is busy. Please try again shortly."
    UiError.BAD_REQUEST -> "The request was rejected. Check the model name in Settings."
    UiError.SERVER -> "The AI service had a problem. Please try again."
    UiError.NETWORK -> "I couldn't reach the internet. Check your connection and try again."
    UiError.TIMEOUT -> "That took too long. Please try again."
    UiError.BAD_RESPONSE -> "I got a reply I couldn't read. Please try again."
    UiError.UNKNOWN -> "Something went wrong. Please try again."
    UiError.MIC_DENIED -> "Microphone permission was denied. You can still type to me with the keyboard button."
    UiError.MIC_BLOCKED -> "Microphone access is blocked. Enable it in the app's system settings, or type to me."
    UiError.SPEECH_UNAVAILABLE -> "Speech recognition isn't available on this device. You can type to me instead."
    UiError.SPEECH_NO_MATCH -> "I didn't catch that. Tap the mic and try again."
    UiError.SPEECH_NETWORK -> "Speech recognition needs a connection right now. Try again or type to me."
    UiError.SPEECH_BUSY -> "The speech service is busy. Try again in a moment."
    UiError.SPEECH_OTHER -> "Voice input failed. Try again or type to me."
    UiError.CAPTURE_DENIED -> "Screen sharing wasn't allowed, so I didn't capture anything."
    UiError.CAPTURE_FAILED -> "I couldn't capture the screen. Some apps block screenshots."
    UiError.NO_CAMERA_APP -> "No camera app was found on this device."
    UiError.PHOTO_FAILED -> "I couldn't read that photo. Please try again."
    UiError.FILE_FAILED -> "I couldn't read that file. Pick a plain text file."
    UiError.APP_FAILED -> "I couldn't open that app."
}
