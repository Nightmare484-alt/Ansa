package com.maya.assistant.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.maya.assistant.R

/**
 * Takes exactly ONE screenshot after a short delay (so the user can switch to the screen they
 * want to share), hands the JPEG to [CaptureBus], then stops itself. Nothing is recorded or saved.
 */
class ScreenCaptureService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var finished = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        val delay = intent.getLongExtra(EXTRA_DELAY_MS, DEFAULT_DELAY_MS)

        // Android 14 requires the mediaProjection foreground service to be running BEFORE getMediaProjection().
        startAsForeground()
        if (code != Activity.RESULT_OK || data == null) {
            finish(CaptureResult.Failure(CaptureFailure.DENIED))
            return START_NOT_STICKY
        }
        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mgr.getMediaProjection(code, data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() = finish(CaptureResult.Failure(CaptureFailure.STOPPED))
            }, handler)
            handler.postDelayed({ capture() }, delay)
            handler.postDelayed({ finish(CaptureResult.Failure(CaptureFailure.TIMEOUT)) }, delay + 8_000)
        } catch (e: Exception) {
            finish(CaptureResult.Failure(CaptureFailure.ERROR))
        }
        return START_NOT_STICKY
    }

    private fun capture() {
        val p = projection ?: return
        try {
            val dm = resources.displayMetrics
            val scale = ImageUtils.scaleFor(dm.widthPixels, dm.heightPixels)
            val w = (dm.widthPixels * scale).toInt().coerceAtLeast(1)
            val h = (dm.heightPixels * scale).toInt().coerceAtLeast(1)
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            display = p.createVirtualDisplay(
                "maya-capture", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler,
            )
            // Give the virtual display a moment to render its first frame.
            handler.postDelayed({
                val image = r.acquireLatestImage()
                if (image == null) {
                    finish(CaptureResult.Failure(CaptureFailure.NO_FRAME))
                } else {
                    val jpeg = try {
                        ImageUtils.toJpeg(imageToBitmap(image, w, h))
                    } finally {
                        image.close()
                    }
                    finish(CaptureResult.Success(jpeg))
                }
            }, 700)
        } catch (e: Exception) {
            finish(CaptureResult.Failure(CaptureFailure.ERROR))
        }
    }

    private fun imageToBitmap(image: Image, w: Int, h: Int): Bitmap {
        val plane = image.planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * w
        val padded = Bitmap.createBitmap(w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        return if (padded.width == w) padded else Bitmap.createBitmap(padded, 0, 0, w, h)
    }

    private fun finish(result: CaptureResult) {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        display?.release()
        reader?.close()
        projection?.stop()
        display = null
        reader = null
        projection = null
        CaptureBus.emit(result)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.capture_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val notification: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_screen)
            .setContentTitle("Maya is taking one screenshot")
            .setContentText("It stops by itself right after. Nothing is recorded.")
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION,
        )
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "maya_capture"
        private const val NOTIFICATION_ID = 42
        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_DATA = "data"
        private const val EXTRA_DELAY_MS = "delay_ms"
        const val DEFAULT_DELAY_MS = 5_000L

        fun start(context: Context, resultCode: Int, data: Intent, delayMs: Long = DEFAULT_DELAY_MS) {
            val intent = Intent(context, ScreenCaptureService::class.java)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
                .putExtra(EXTRA_DELAY_MS, delayMs)
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
