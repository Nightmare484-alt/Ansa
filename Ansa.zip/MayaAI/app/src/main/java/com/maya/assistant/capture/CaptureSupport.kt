package com.maya.assistant.capture

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.io.ByteArrayOutputStream
import java.io.File

sealed interface CaptureResult {
    class Success(val jpeg: ByteArray) : CaptureResult
    data class Failure(val reason: CaptureFailure) : CaptureResult
}

enum class CaptureFailure { DENIED, STOPPED, NO_FRAME, TIMEOUT, ERROR }

/** In-process hand-off from [ScreenCaptureService] to the ViewModel. Nothing is persisted. */
object CaptureBus {
    private val _results = MutableSharedFlow<CaptureResult>(extraBufferCapacity = 1)
    val results: SharedFlow<CaptureResult> = _results.asSharedFlow()
    fun emit(result: CaptureResult) {
        _results.tryEmit(result)
    }
}

object ImageUtils {
    const val MAX_EDGE = 1280

    fun sampleSize(width: Int, height: Int, maxEdge: Int = MAX_EDGE): Int {
        var sample = 1
        var longest = maxOf(width, height)
        while (longest / 2 >= maxEdge) {
            longest /= 2
            sample *= 2
        }
        return sample
    }

    fun scaleFor(width: Int, height: Int, maxEdge: Int = MAX_EDGE): Float =
        minOf(1f, maxEdge.toFloat() / maxOf(width, height))

    fun toJpeg(bitmap: Bitmap, quality: Int = 80): ByteArray =
        ByteArrayOutputStream().also { bitmap.compress(Bitmap.CompressFormat.JPEG, quality, it) }.toByteArray()

    /** Decodes a camera photo, applies EXIF rotation, downsizes it, and returns JPEG bytes (or null). */
    fun decodePhoto(file: File): ByteArray? {
        if (!file.exists() || file.length() == 0L) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0) return null
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight) }
        var bmp = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return null
        val degrees = try {
            when (ExifInterface(file.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
        if (degrees != 0f) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees) }, true)
        }
        return toJpeg(bmp)
    }
}
