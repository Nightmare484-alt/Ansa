#!/data/data/com.termux/files/usr/bin/bash
# Runs unit tests and builds the debug APK in Termux. Pass your own Gradle tasks to override.
#   ./scripts/build-termux.sh                       -> tests + debug APK
#   ./scripts/build-termux.sh :app:assembleDebug    -> APK only (faster, less RAM)
set -euo pipefail
cd "$(dirname "$0")/.."

export JAVA_HOME="$PREFIX/lib/jvm/java-17-openjdk"
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$HOME/gradle-8.10.2/bin:$PATH"
echo "sdk.dir=$ANDROID_HOME" > local.properties

if [ $# -eq 0 ]; then set -- :app:testDebugUnitTest :app:assembleDebug; fi

gradle --no-daemon --console=plain \
  -Pandroid.aapt2FromMavenOverride="$PREFIX/bin/aapt2" \
  "$@"

APK=app/build/outputs/apk/debug/app-debug.apk
if [ -f "$APK" ]; then
  echo "APK: $PWD/$APK"
  if [ -d "$HOME/storage/downloads" ]; then
    cp "$APK" "$HOME/storage/downloads/MayaAI-debug.apk" && echo "Copied to Downloads/MayaAI-debug.apk"
  else
    echo "Run 'termux-setup-storage' once to copy the APK to Downloads, or use: termux-open $APK"
  fi
fi
